const mealRecipes = [
  {
    "id": 1,
    "title": "Greek Salad",
    "price": 12.99,
    "image": "https://i.ibb.co/68c9bLv/greek-salad.jpg", 
    "description": "Little Lemon Restaurant, situated in a comfortable nook"
  },
  {
    "id": 2,
    "title": "Bruschetta",
    "price": 5.99,
    "image": "https://i.ibb.co/317GqZv/Bruchetta.png", 
    "description": "Little Lemon Restaurant, situated in a comfortable nook"
  },
  {
    "id": 3,
    "title": "Lemon Dessert",
    "price": 4.78,
    "image": "https://i.ibb.co/sm6MfcH/desert.jpg", 
    "description": "Little Lemon Restaurant, situated in a comfortable nook"
  }
];

export default mealRecipes